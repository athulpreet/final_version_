/*
  
  Name: CORSA-2
  Purpose: AIR PURIFIER.

  @author ATHUL PREET
	
	bug fix:
	
	1) stuck probrlem fix(caused by a flag not reinit to 0)
  
*/


#include <stm32f042x6.h>
#include "main.h"
#include "math.h"
#include "string.h"
#include "fonts.h"
#include "ssd1306.h"
#include "zh06.h"
#include "TMEP.h"
#include "FAN.h"
#include "buttons.h"
#include <stdio.h>


int dummy222=0;
int transit_flag=0;
float dust_usa=0;
int std_spot1=0;
int std_spot2=0;

volatile int set_sel1=1;
volatile int set_sel2=1;

int no_sensor_flag=0;


I2C_HandleTypeDef hi2c1;
void fan_uv(void);
int dust_cal(void);
int color_aqi=0;
int sec=0;
int min=0;
int hrs=0;
int day=0;
int month=0;
int filter_while_delay=0;

volatile int filter_change_color_flag=0;
volatile int filter_change_color_flag2=0;
volatile int startup_color_flag=0;
volatile int calib_color_flag=0;
volatile int calib_color_flag_done=0;

volatile int SET_INC=0;
volatile int set_delay=0;
volatile int switch_flag=0;
volatile int sett_flag=0;
 int led_off_flag=0;
int halt_flag=0;

int aqi_dot_flag=0;
int no_dots=0;
float cal_x=6;
int cal_y=0;
int set_cal=0;
void fan_uv_mode3(void);
unsigned long previousMillis_buzzer=0;
unsigned long leds_times_previousMillis=0;
unsigned long leds_temptimes_previousMillis=0;


unsigned long last_val=0;

const long interval_buzzer_changefilter=10000 *(60*2);
int	buzzerState=0;
void buzzer_init(void){
RCC->AHBENR |=(1<<17);
GPIOA->MODER |=(1<<0);
GPIOA->MODER &=~(1<<1);
GPIOA->PUPDR &=~(1<<0);
GPIOA->PUPDR &=~(1<<0);
}
#define MAX_LED 3
uint16_t pwmData[(24*MAX_LED)+100];
volatile short datasentflag=0;
int dummy_inc=0;
int R=0;
int tr=0;
int G=0;
int B=0;
int increment=0;
int i=0;
int ii=0;
int iI=0;
int iII=0;
int ind=0;
int pwm_data_num=0;
uint32_t color=0;
int X=0,Y=0,Z=0,AQI=0;
float AQI2=0;
int k=0;
uint8_t LED_Data[MAX_LED][4];
uint8_t LED_Mod[MAX_LED][4];
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_I2C1_Init(void);
volatile unsigned long previousMillis_tempAQI = 0;        
 int interval_tempAQI = 20000; 
int tempAQI_state=0;
short status=0;
int temp_offset=0;
int offset_final=0;
int sign_offset =0;
int xsign_offset =0;
int signs=0;
unsigned long led_previousMillis = 0;       
const long led_interval = 1000; 
volatile int  FANPWM=0;
volatile int ledState=0;
void purifier(void );
void sanitizer(void );
void silent(void );
void standby(void );
void set_fun();
short menu_val=1;
short dis_flag=1;
volatile int adelay=0;
volatile int temp_delay=0;
char calib_temp_val[3];
char caltemp[3];
char calib_offset_val[3];
int dust_val=0;
uint32_t dust=0;
volatile short mode=1;
short degreeC=0;
short calib_mode=0;
int incr_delay=0;
short offset=16;
char caloffset[3];
short cal_flag=0;
short offset_read=0;
short xoffset_read=0;
int aqi_reading_flag=0;
int times_no=0;
int selection_no=0;
	int sel_sel1=0;
	int sel_sel2=0;
	int SEl_INC=0;
	int sel_delay=0;
	int halt_flag_2=0;
	int sell_flag=0;

//cal inc
int xincr_delay=0;
volatile int xppm=0;
int xoffset_final=0;
int xsigns=0;
char xcaloffset[3];
short xcal_flag=0;



unsigned long times_previousMillis = 0;       
const long times_interval = 1000; 


//cal_setting variable init
volatile int calset_delay=0;
int calhalt_flag=0;
volatile int calSET_INC=0;
volatile int calset_sel1=1;
volatile int calset_sel2=1;
volatile int calsett_flag=0;

volatile int ppm=0;
char print_ppm[3];
char print_storedppm[3];


volatile int incdecset_delay=0;
int incdechalt_flag=0;
volatile int incdecSET_INC=0;
volatile int incdecset_sel1=1;
volatile int incdecset_sel2=1;
volatile int incdecsett_flag=0;

volatile int storedppm=0;



//fault
			int variable_got1=0;
			int variable_got2=1;
		unsigned long	gotpreviousMillis=0;
int gotState=0;
int got_counter=0;


//map function declration 
long map(long x, long in_min, long in_max, long out_min, long out_max) {
return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}


long map2(float x, float in_min, float in_max, float out_min, float out_max) {
	
	float finals=0;
	finals=(x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
	
return finals;
}

/*
function Linear(AQIhigh, AQIlow, Conchigh, Conclow, Concentration)
{
var linear;
var Conc=parseFloat(Concentration);
var a;
a=((Conc-Conclow)/(Conchigh-Conclow))*(AQIhigh-AQIlow)+AQIlow;
linear=Math.round(a);
return linear;
}

*/





//led strip dma init
void DMA_INIT(void){	
TIM16->DIER|=(1<<9);
DMA1_Channel3->CPAR=(uint32_t)&(TIM16->CCR1);
DMA1_Channel3->CMAR=(uint32_t) &pwmData;
DMA1_Channel3->CNDTR=(24*MAX_LED)+100;	
DMA1_Channel3->CCR |=(1<<7);	
DMA1_Channel3->CCR |=(1<<10);
DMA1_Channel3->CCR &=~(1<<11);
DMA1_Channel3->CCR |=(1<<8);
DMA1_Channel3->CCR &=~(1<<9);
DMA1_Channel3->CCR |=(1<<4);
	//DMA1_Channel3->CCR |=(1<<5);
DMA1_Channel3->CCR |=(1<<1);
}

//led strip timer init
void TIM16_CONFIG(void){
RCC->AHBENR |=(1<<18);
RCC->APB2ENR |=(1<<17);
RCC->AHBENR |=(1<<0);
GPIOB->MODER |=(1<<17);
GPIOB->MODER &=~(1<<16);
GPIOA->OTYPER &=~(1<<8);
GPIOA->OSPEEDR |=(1<<17);
GPIOA->OSPEEDR |=(1<<16);
GPIOB->AFR[1]|=(1<<1);
GPIOB->AFR[1]&=~(1<<0);
GPIOB->AFR[1]&=~(1<<2);
GPIOB->AFR[1]&=~(1<<3);
TIM16->PSC =0;
TIM16->ARR =9;
TIM16->CCMR1 |=(1<<6);
TIM16->CCMR1 |=(1<<5);
TIM16->CCMR1 &=~(1U<<4);
TIM16->CCMR1 |=(1<<3);
TIM16->CR1 |=(1<<7);
TIM16->CCER &=~(1<<1);
TIM16->CCER |=(1<<0);
TIM16->BDTR |=(1<<15);
TIM16->CR2 |=(1<<3);
DMA_INIT();
}

//led strip color and number function
void Set_LED (int LEDnum, int Red, int Green, int Blue)
{
LED_Data[LEDnum][0] = LEDnum;
LED_Data[LEDnum][1] = Green;
LED_Data[LEDnum][2] = Red;
LED_Data[LEDnum][3] = Blue;
}

//led strip function
void TRANS(int guy){
ind=0;
dummy_inc=guy;
	//HAL_Delay(50);
	////dummy_inc++;
	//if(dummy_inc>=150){dummy_inc=0;}
/*	
if(dummy_inc >= 0 && dummy_inc <=250){
X= map(dummy_inc,0,250,0,255);
Y= map(dummy_inc,0,250,0,126);
Z= map(dummy_inc,0,250,255,6);
} 
if(dummy_inc > 250 && dummy_inc <=500){
X= 255;
Y= map(dummy_inc,250,500,126,0);
Z= map(dummy_inc,250,500,6,0);
}
if(dummy_inc > 500){
X= 255;
Y= 0;
Z= 0;
}
	*/
	
	
	
		
		
	if(dummy_inc >= 0 && dummy_inc <=150){
X= map(dummy_inc,0,150,0,255);
Y= map(dummy_inc,0,150,255,0);
Z= 0;
} 
	if(dummy_inc > 150){
X= 255;
Y= 0;
Z= 0;
}
	
	
Set_LED(0, X,Y ,Z);	
Set_LED(1, X,Y ,Z);	
Set_LED(2, X,Y ,Z);

//filter_change_color_flag=1;

if(filter_change_color_flag==1){
filter_change_color_flag=0;
Set_LED(0, 255,0 ,0);	
Set_LED(1, 255,0 ,0);	
Set_LED(2, 255,0 ,0);
}	

if(filter_change_color_flag2==1){
	filter_change_color_flag2=0;
Set_LED(0, 0,0 ,0);	
Set_LED(1, 0,0 ,0);	
Set_LED(2, 0,0 ,0);
}	

if(startup_color_flag==1){
	startup_color_flag=0;
Set_LED(0, 255,255 ,250);	
Set_LED(1, 255,255 ,250);	
Set_LED(2, 255,255 ,250);
}

if(calib_color_flag==1){
calib_color_flag=0;
		
Set_LED(0, 255,180 ,0);	
Set_LED(1, 255,255 ,185);	
Set_LED(2, 0,255 ,0);
}	
if(calib_color_flag_done==1){
	calib_color_flag_done=0;
Set_LED(0, 0,0 ,255);	
Set_LED(1, 0,0 ,255);	
Set_LED(2, 0,0 ,255);
}

if(led_off_flag==1){
	//led_off_flag=0;
Set_LED(0, 0,0 ,0);	
Set_LED(1, 0,0 ,0);	
Set_LED(2, 0,0 ,0);
}	



for (increment=0;increment<MAX_LED;increment++){
color = ((LED_Data[increment][1]<<16) | (LED_Data[increment][2]<<8) | LED_Data[increment][3]);
for ( ii=23; ii>=0; ii--)
{
if (color&(1<<ii))
{
pwmData[ind] = 7; 
}
else pwmData[ind] = 3;
ind++;
}
}


HAL_Delay(10);

TIM16->CR1 |=(1<<0);

TIM16->EGR |=(1<<0);

DMA1_Channel3->CCR |=(1<<0);


while((DMA1->ISR & (1<<9))){


DMA1->IFCR |=(1<<9);
TIM16->CR1 &=~(1<<0);
DMA1_Channel3->CCR &=~(1<<0);
//HAL_Delay(50);
while((DMA1->ISR & (1<<9))){


DMA1->IFCR |=(1<<9);
TIM16->CR1 &=~(1<<0);
DMA1_Channel3->CCR &=~(1<<0);
//HAL_Delay(50);
}

}

HAL_Delay(100);






}



//eeprom write
void write(int addr,int data){
uint8_t data_to_write=data;
uint8_t addr_to_write = addr;
HAL_I2C_Mem_Write(&hi2c1 ,0xA0,addr_to_write, 0x01,&data_to_write,1,10);
}

//eeprom read
int read(int addr){
uint8_t addr_to_read=addr;
uint8_t data_read;
HAL_I2C_Mem_Read(&hi2c1 ,0xA0,addr_to_read, 0x01,&data_read,1,1);
return data_read;
}

//change filter function (edit line 668 also)
void seconds(void){
volatile unsigned long currentMillis = counter;
if(currentMillis-previousMillis >=interval){
previousMillis=currentMillis;
sec++;
if(sec>=60){
sec=0;
min++;
write(100,min);
HAL_Delay(100);
	
			if(min>=60){
			min=0;
			write(100,min);
			HAL_Delay(100);	
			hrs++;
			write(105,hrs);
			HAL_Delay(100);
				
						if(hrs>=24){
						hrs=0;
							write(105,hrs);
							HAL_Delay(100);
						day++;
						write(110,day);
						HAL_Delay(100);
							
									if(day>=30){
									day=0;
									write(110,day);
									HAL_Delay(100);
									month++;
									write(115,month);	
									HAL_Delay(100);
                  }
            }
     }
}
if(month>=3)
{
SSD1306_Clear();
SSD1306_GotoXY(35,13);
SSD1306_Puts ("CHANGE", &Font_11x18, 1);
SSD1306_UpdateScreen();		
SSD1306_GotoXY(35,44);
SSD1306_Puts ("FILTER", &Font_11x18, 1);
SSD1306_UpdateScreen();
	
fan_uv_mode3();		
//GPIOA->ODR |=(1<<7);
//GPIOB->BSRR &=~(1<<1);
//GPIOB->BSRR |=(1<<17);
	filter_change_color_flag2=1;	
									TIM16_CONFIG();
									TRANS(dust_cal());
									HAL_Delay(40);

			
while(month>=3){
	
unsigned long currentMillis_buzzer_changefilter = counter;
if (currentMillis_buzzer_changefilter - previousMillis_buzzer >= interval_buzzer_changefilter) {
previousMillis_buzzer = currentMillis_buzzer_changefilter;
if (buzzerState == 0) {
buzzerState = 1;
	
GPIOA->BSRR |=(1<<0);
									filter_change_color_flag=1;	
									TIM16_CONFIG();
									TRANS(dust_cal());
									HAL_Delay(40);	
HAL_Delay(100);
	
GPIOA->BSRR |=(1<<16);
									filter_change_color_flag2=1;	
									TIM16_CONFIG();
									TRANS(dust_cal());
									HAL_Delay(40);
HAL_Delay(300);

GPIOA->BSRR |=(1<<0);
									filter_change_color_flag=1;	
									TIM16_CONFIG();
									TRANS(dust_cal());
									HAL_Delay(40);	
HAL_Delay(100);

GPIOA->BSRR |=(1<<16);
									filter_change_color_flag2=1;	
									TIM16_CONFIG();
									TRANS(dust_cal());
									HAL_Delay(40);	

}else{
buzzerState = 0;
GPIOA->BSRR |=(1<<16);
									filter_change_color_flag2=1;	
									TIM16_CONFIG();
									TRANS(dust_cal());
									HAL_Delay(40);	
}
}
if(GPIOA->IDR &(1<<1)){
filter_while_delay++;
HAL_Delay(1000);
}
if(filter_while_delay > 5){
min=0;
write(100,0);
HAL_Delay(100);
hrs=0;
write(105,0);
HAL_Delay(100);
day=0;
write(110,0);
HAL_Delay(100);
month=0;
write(115,0);
HAL_Delay(100);
filter_while_delay=0;
filter_change_color_flag=0;
SSD1306_Clear();
}
}
}
}
}

//menu display after switching on 
void present_menu(void){
switch (mode){
case 1: purifier();
break;
case 2: sanitizer();
break;
case 3:silent();
break;
case 4: standby();
break;
}}

//temp function
void temp(void){
	
degreeC=adc_to_mv();

	
if(sign_offset==0){
degreeC=degreeC+offset_read;
}
else if(sign_offset==1){
degreeC=degreeC-offset_read;
}
else if(offset_read==0){
degreeC=degreeC;
}



sprintf(caltemp,"%d",degreeC);

SSD1306_GotoXY(1,29);
SSD1306_Puts ("TEMP", &Font_16x26, 1);            
SSD1306_GotoXY(72,29);
SSD1306_Puts (caltemp, &Font_16x26, 1);
SSD1306_GotoXY(103,6);
SSD1306_Puts("o", &Font_11x18, 1);
SSD1306_GotoXY(107,29);
SSD1306_Puts("C", &Font_16x26, 1); 
SSD1306_UpdateScreen();	
}







//calibration mode function


//********************************************************************************
void calibration_inc(){
	
	sprintf(print_storedppm,"%d",storedppm); 
	
	        	SSD1306_GotoXY(30,10);
            SSD1306_Puts ("PPM", &Font_11x18, 1); 
	          SSD1306_GotoXY(92,10);
            SSD1306_Puts ("  ", &Font_11x18, 1);
            SSD1306_GotoXY(77,10);
            SSD1306_Puts (print_storedppm, &Font_11x18, 1);
					  SSD1306_UpdateScreen();	
	
	
	
if(GPIOA->IDR &(1<<1)){
	 SSD1306_Clear();
	
while(xincr_delay<=1000000){
xincr_delay++;
if(GPIOA->IDR &(1<<1)){
HAL_Delay(200);
xincr_delay=0;
SSD1306_Clear();
storedppm++;
	if(storedppm>=150){storedppm=0;}
	
	
			if((a[0]==66)&&(a[1]==77)){
xppm=a[12]<<8|a[13];
	
	}
	if((a[1]==66)&&(a[2]==77)){
xppm=a[13]<<8|a[14];
		
	}
	
	
if(xppm<storedppm){
xoffset_final=storedppm-xppm;
xsigns=0;
}	 
else if(xppm>storedppm){
xoffset_final=xppm-storedppm;
xsigns=1;
}
else if(xppm==storedppm){
xoffset_final=0;
}
sprintf(xcaloffset,"%d",storedppm);
            SSD1306_GotoXY(30,10);
            SSD1306_Puts ("PPM", &Font_11x18, 1); 
	          SSD1306_GotoXY(92,10);
            SSD1306_Puts ("  ", &Font_11x18, 1);
            SSD1306_GotoXY(77,10);
            SSD1306_Puts (xcaloffset, &Font_11x18, 1);
					  SSD1306_UpdateScreen();																				
}		
xcal_flag=1;
}
if(xcal_flag==1){
	
	
write(50,xsigns);
HAL_Delay(200);
write(60,xoffset_final);
HAL_Delay(3000);
	
SSD1306_Clear();
SSD1306_GotoXY(10,25);
SSD1306_Puts ("D O N E ", &Font_16x26, 1);
SSD1306_UpdateScreen();
	HAL_Delay(3000);
	                
	
	
	HAL_NVIC_SystemReset();
}	
}
}	

void calibration_dec(){
	
	sprintf(print_storedppm,"%d",storedppm); 
	
	        	SSD1306_GotoXY(30,10);
            SSD1306_Puts ("PPM", &Font_11x18, 1); 
	          SSD1306_GotoXY(92,10);
            SSD1306_Puts ("  ", &Font_11x18, 1);
            SSD1306_GotoXY(77,10);
            SSD1306_Puts (print_storedppm, &Font_11x18, 1);
					  SSD1306_UpdateScreen();	
	
	
	
if(GPIOA->IDR &(1<<1)){
	 SSD1306_Clear();
	
while(xincr_delay<=1000000){
xincr_delay++;
if(GPIOA->IDR &(1<<1)){
HAL_Delay(200);
xincr_delay=0;
SSD1306_Clear();
storedppm--;
	if(storedppm<=0){storedppm=150;}
	
	
			if((a[0]==66)&&(a[1]==77)){
xppm=a[12]<<8|a[13];
	
	}
	
	
	
if(xppm<storedppm){
xoffset_final=storedppm-xppm;
xsigns=0;
}	 
else if(xppm>storedppm){
xoffset_final=xppm-storedppm;
xsigns=1;
}
else if(xppm==storedppm){
xoffset_final=0;
}
sprintf(xcaloffset,"%d",storedppm);
            SSD1306_GotoXY(30,10);
            SSD1306_Puts ("PPM", &Font_11x18, 1); 
	          SSD1306_GotoXY(92,10);
            SSD1306_Puts ("  ", &Font_11x18, 1);
            SSD1306_GotoXY(77,10);
            SSD1306_Puts (xcaloffset, &Font_11x18, 1);
					  SSD1306_UpdateScreen();																				
}		
xcal_flag=1;
}
if(xcal_flag==1){
	
	
write(50,xsigns);
HAL_Delay(200);
write(60,xoffset_final);
HAL_Delay(3000);
	
SSD1306_Clear();
SSD1306_GotoXY(10,25);
SSD1306_Puts ("D O N E ", &Font_16x26, 1);
SSD1306_UpdateScreen();
	HAL_Delay(3000);
	                
	
	
	HAL_NVIC_SystemReset();
}	
}
}	
//********************************************************************************








void calibration_mode(){
	
	        
				  SSD1306_GotoXY(18,25);
					SSD1306_Puts ("UPDATE", &Font_16x26, 1);
					SSD1306_UpdateScreen();
	
	
	
if(GPIOA->IDR &(1<<1)){
	 SSD1306_Clear();
	
while(incr_delay<=1000000){
incr_delay++;
if(GPIOA->IDR &(1<<1)){
HAL_Delay(200);
incr_delay=0;
SSD1306_Clear();
offset++;
	if(offset>=50){offset=0;}
degreeC=adc_to_mv();
if(degreeC<offset){
offset_final=offset-degreeC;
signs=0;
}	 
else if(degreeC>offset){
offset_final=degreeC-offset;
signs=1;
}
else if(degreeC==offset){
offset_final=0;
}
sprintf(caloffset,"%d",offset);
SSD1306_GotoXY(50,27);
SSD1306_Puts (caloffset, &Font_16x26, 1);
SSD1306_UpdateScreen();																					
}		
cal_flag=1;
}
if(cal_flag==1){
	
	
write(30,signs);
HAL_Delay(200);
write(10,offset_final);
HAL_Delay(3000);
SSD1306_Clear();
SSD1306_GotoXY(10,25);
SSD1306_Puts ("D O N E ", &Font_16x26, 1);
SSD1306_UpdateScreen();
	
	                calib_color_flag_done=1;	
	                TIM16_CONFIG();
									TRANS(dust_cal());
									HAL_Delay(3500);
	
	
	HAL_NVIC_SystemReset();
}	
}
}	

//ppm to aqi conversion function
int dust_cal(void){
	
dust=a[12]<<8|a[13];
	
	

	
//startup_color_flag=1;

	if(!((a[12]<<8|a[13])==0))
	{
	
	//	startup_color_flag=0;
		
	if(xsign_offset==0){
dust=dust+xoffset_read;
}
else if(xsign_offset==1){
dust=dust-xoffset_read;
}
else if(xoffset_read==0){
dust=dust;
}
	
	
	}
	
	
	
	
	
	if(sell_flag==1){
if(dust<=30){dust=dust*1.66667;}
else if(dust>30&&dust<=60){dust=50+(dust-30)*1.66667;}
else if (dust>60&&dust<=90)                  {dust=100+(dust-60)*3.33333;}
else if (dust>90&&dust<=120)                 {dust=200+(dust-90)*3.33333;}
else if (dust>120&&dust<=250)                {dust=300+(dust-120)*0.76923;}
else if (dust>250)                           {dust=400+(dust-250)*0.76923;}

}
	
else if(sell_flag==2){
dust_usa=dust;

if(dust_usa>=0 && dust_usa<13)                       {dust= map2(dust_usa,0,12,0,50);}
else if(dust_usa>=13 && dust_usa<36)                 { dust= map2(dust_usa,13,35,51,100);}
else if(dust_usa>=36 && dust_usa<56)	               { dust= map2(dust_usa,36,55,101,150);}
else if(dust_usa>=56 && dust_usa<151)	                 { dust= map2(dust_usa,56,150,151,200);}
else if(dust_usa>=151 && dust_usa<251)	                { dust=  map2(dust_usa,151,250,201,300);}
else if(dust_usa>=251 && dust_usa<351)	               { dust= map2(dust_usa,251,350,301,400);}
else if(dust_usa>=351 && dust_usa<501)	               { dust= map2(dust_usa,351,500,401,501);}	              
		

}
return dust;
}

//aqi display function
void aqi(void)
{
	/*
if(dust_cal()==0){
		SSD1306_GotoXY(9,26);
SSD1306_Puts ("AQI", &Font_16x26, 1); 
SSD1306_GotoXY(66,26);
SSD1306_Puts (".   ", &Font_16x26, 1);
	SSD1306_UpdateScreen();
	//HAL_Delay(30);
	SSD1306_GotoXY(66,26);
SSD1306_Puts ("..  ", &Font_16x26, 1);
	SSD1306_UpdateScreen();
	//HAL_Delay(30);
	SSD1306_GotoXY(66,26);
	SSD1306_Puts ("... ", &Font_16x26, 1);
	SSD1306_UpdateScreen();
	//HAL_Delay(30);
	
	aqi_dot_flag=1;
	
	}
*/

//SSD1306_Clear();

//if(!(dust_cal()==0))
//{
	aqi_dot_flag=0;
dust_val=dust_cal();
	/*
	if(dust_val>200){
	GPIOA->BSRR |=(1<<0);
HAL_Delay(100);
GPIOA->BSRR |=(1<<16);
		
	
	}
	*/
	if(dust_val>500)
	{
		dust_val=500;

	SSD1306_GotoXY(115,6);
SSD1306_Puts("+", &Font_11x18, 1);

		
		SSD1306_UpdateScreen();
		HAL_Delay(30);
	}
	
	if(dust_val<=500){
	
	SSD1306_GotoXY(115,6);
SSD1306_Puts(" ", &Font_11x18, 1);
	
	
	}
	
	if(dust_val<=0){
	
	dust_val=0;
	}
	
sprintf(calib_temp_val,"%d",dust_val); 
SSD1306_GotoXY(9,26);
SSD1306_Puts ("AQI", &Font_16x26, 1); 
	SSD1306_GotoXY(71,26);
SSD1306_Puts ("  ", &Font_16x26, 1);

	
	if(!((a[12]<<8|a[13])==0)){
		no_sensor_flag=0;
SSD1306_GotoXY(76,26);
SSD1306_Puts (calib_temp_val, &Font_16x26, 1);
if(dust_val<100){
SSD1306_GotoXY(108,26);	
SSD1306_Puts ("          ", &Font_16x26, 1);	
		}

		if(dust_val<10){
SSD1306_GotoXY(98,26);	
SSD1306_Puts ("          ", &Font_16x26, 1);	
		}
		
	}
	
	
	if((a[0]==0)&&(a[1]==0)){
	
		no_sensor_flag=1;
		
	startup_color_flag=1;
	SSD1306_GotoXY(76,26);
SSD1306_Puts ("----", &Font_16x26, 1);
	
	
	}
	
	

SSD1306_UpdateScreen();
		
		/*
		if(dust_val>100){
		times_no++;
		}
		
		else{
		        times_no=0;
		}
		
		if(times_no==1){
		
		GPIOA->BSRR |=(1<<0);
HAL_Delay(50);
GPIOA->BSRR |=(1<<16);
HAL_Delay(100);
GPIOA->BSRR |=(1<<0);
HAL_Delay(50);
GPIOA->BSRR |=(1<<16);
		
		
		}
		
		
		
		
		
		
		
		
		
		if(dust_val>250){
	
	
		
		unsigned long times_currentMillis = counter;
if (times_currentMillis - times_previousMillis >= 3000) {
times_previousMillis = times_currentMillis;

GPIOA->BSRR |=(1<<0);
HAL_Delay(50);
GPIOA->BSRR |=(1<<16);
HAL_Delay(100);
GPIOA->BSRR |=(1<<0);
HAL_Delay(50);
GPIOA->BSRR |=(1<<16);

}
		
		
}		
*/
//}
}
//purifier mode display
void purifier(){
SSD1306_GotoXY(23,30);
SSD1306_Puts ("PURIFIER    ", &Font_11x18, 1);             
SSD1306_UpdateScreen();
}

//silent mode display
void silent(void){
SSD1306_GotoXY(34,30);
SSD1306_Puts ("SILENT    ", &Font_11x18, 1);         
SSD1306_UpdateScreen();
}

//auto mode display
void sanitizer(void){
SSD1306_GotoXY(38,30);
SSD1306_Puts ("AUTO     ", &Font_11x18, 1);      
SSD1306_UpdateScreen();
}

//standby mode display
void standby(void){
SSD1306_GotoXY(25,30);
SSD1306_Puts ("STANDBY   ", &Font_11x18, 1);          
SSD1306_UpdateScreen();
}
void settings(void){
 SSD1306_GotoXY(20,30);
					SSD1306_Puts ("SETTINGS", &Font_11x18, 1);
					SSD1306_UpdateScreen();	
}



//aqi and temp change
//uv led and fan working
//led strip color transistion


void dust_whole(){


	
aqi();
	
fan_uv();
if(aqi_dot_flag==1){startup_color_flag=1;}











//TIM16_CONFIG();
//TRANS(dust_cal());



tempAQI_state = 1;
//HAL_Delay(100);

}


void temp_whole(){

if(aqi_dot_flag==1){startup_color_flag=1;}
temp();
fan_uv();
	

//TIM16_CONFIG();
//TRANS(dust_cal());

tempAQI_state = 0;



}



void home(void){
	
	
	
	if(interval_tempAQI==20000){
	
		
		GPIOB->BSRR &=~(1<<17);
GPIOB->BSRR |=(1<<1);
TIM14->CR1 &=~(1<<0);
TIM14->CCR1 = 7000;
TIM14->EGR |=(1<<0);
TIM14->CR1 |=(1<<0);
		
	SSD1306_GotoXY(0,26);
		
SSD1306_Puts ("STARTING", &Font_11x18, 1); 
		//SSD1306_UpdateScreen();
		
		
		HAL_Delay(10);
SSD1306_GotoXY(90,26);
SSD1306_Puts (".   ", &Font_11x18, 1);
	SSD1306_UpdateScreen();
	HAL_Delay(10);
	SSD1306_GotoXY(90,26);
SSD1306_Puts ("..  ", &Font_11x18, 1);
	SSD1306_UpdateScreen();
	HAL_Delay(10);
	SSD1306_GotoXY(90,26);
	SSD1306_Puts ("... ", &Font_11x18, 1);
	SSD1306_UpdateScreen();
	HAL_Delay(10);
		
tempAQI_state=1;
	}
	
	
	
	
	if((transit_flag==1)&&(no_sensor_flag==0))
	{
			unsigned long leds_temptimes_currentMillis = counter;
if (leds_temptimes_currentMillis - leds_temptimes_previousMillis >= 100) {
leds_temptimes_previousMillis = leds_temptimes_currentMillis;

TIM16_CONFIG();
TRANS(dust_cal());

	
}
}
	
volatile unsigned long currentMillis_tempAQI = counter;
if (currentMillis_tempAQI - previousMillis_tempAQI >= interval_tempAQI) {
previousMillis_tempAQI = currentMillis_tempAQI;
	
if (tempAQI_state == 0){	
	//if(interval_tempAQI==5000){
	
		aqi_reading_flag=1;
	SSD1306_Clear();
	switch_flag=0;
	tempAQI_state = 1;
	interval_tempAQI=3000;
	transit_flag=1;
	//}
	
}
else{
	SSD1306_Clear();
	switch_flag=1;
	temp_whole();
	tempAQI_state = 0;
	interval_tempAQI=3000;
	
	//
	
	
//
}
}

if(switch_flag==0 && (aqi_reading_flag==1)){
//aqi_reading_flag=0;
	
			
			
			unsigned long got_currentMillis = counter;
			if(got_currentMillis-gotpreviousMillis>=2000){
				
			gotpreviousMillis=got_currentMillis;
				
				 if (gotState == 0) {
      gotState = 1;
					 variable_got1=USART2->RDR;
    } else {
      gotState = 0;
			variable_got2=USART2->RDR;
    }
				
		
		if((variable_got1==variable_got2)){
			
			if(variable_got2==USART2->RDR){
			got_counter++;
			}
			}
				
			}
			
		
			

			
			if(got_counter==4)
			{
				
				//fault_flagg=1;
				/*
		SSD1306_Clear();
		startup_color_flag=1;	
									TIM16_CONFIG();
									TRANS(dust_cal());
									HAL_Delay(40);
		      SSD1306_GotoXY(30,30);
			//SSD1306_ScrollLeft(60,30);
					SSD1306_Puts ("FAULT", &Font_11x18, 1);
			
					SSD1306_UpdateScreen();	
					
		
	while(1){
	 
	}
	*/
}
	
	
	
dust_whole();

}


//********************************************************************
		if(dust_val>100){
		times_no++;
		}
		
		else{
		        times_no=0;
		}
		
		if(times_no==1){
		
		GPIOA->BSRR |=(1<<0);
HAL_Delay(50);
GPIOA->BSRR |=(1<<16);
HAL_Delay(100);
GPIOA->BSRR |=(1<<0);
HAL_Delay(50);
GPIOA->BSRR |=(1<<16);
		
		
		}
		
		
		
		
		
		
		
		
		
		if(dust_val>250){
	
	
		
		unsigned long times_currentMillis = counter;
if (times_currentMillis - times_previousMillis >= 3000) {
times_previousMillis = times_currentMillis;

GPIOA->BSRR |=(1<<0);
HAL_Delay(50);
GPIOA->BSRR |=(1<<16);
HAL_Delay(100);
GPIOA->BSRR |=(1<<0);
HAL_Delay(50);
GPIOA->BSRR |=(1<<16);

}
		
		
}	
//***********************************************************************


}

//menu 
void menu(void){
	HAL_Delay(100);
while(adelay<=50){
adelay++;
if((GPIOA->IDR &(1<<1))&&(butt_flag==1))
{
	HAL_Delay(100);
SSD1306_Clear();
adelay=0;
mode++;
if(mode>5)
{
mode=1;
}


butt_flag=0;
}

else if(!(GPIOA->IDR &(1<<1)))
{

	butt_flag=1;



}
switch (mode){
case 1: purifier();
break;
case 2: sanitizer();
break;
case 3:silent();
break;
case 4: standby();
break;
	case 5: settings();
break;
}
}

if(mode<5){
write(6,mode);
}
SSD1306_Clear();
tempAQI_state=0;
dis_flag=1;
interval_tempAQI=0;

if(mode==5){
           set_fun();
	         mode=read(6);

}


}

//button press going to menu from home function
void corsa(void){
adelay=0;
	
	last_val=counter;
if(GPIOA->IDR &(1<<1))
{
dis_flag=2; 

	
	HAL_Delay(100);
	
	while(GPIOA->IDR &(1<<1)){
	
	if(counter-last_val>=2000)
	{
	  dis_flag=3;
		//while(GPIOA->IDR &(1<<1)){}
			break;
	
	}
	
	}
	
	
	
	
	
	
	
	
	
	
}
switch (dis_flag){
case 1: home();
adelay=0;
break;
case 2:
       SSD1306_Clear();
       menu();
       break;
case 3:   SSD1306_Clear();
	HAL_Delay(200);
	if(led_off_flag==0){
	SSD1306_GotoXY(20,25);
					SSD1306_Puts ("LED OFF", &Font_11x18, 1);
					SSD1306_UpdateScreen();	
	
	led_off_flag=1;
	TIM16_CONFIG();
	TRANS(dust_cal());
	HAL_Delay(40);
	
	led_off_flag=1;
	led_off_flag=1;
	TIM16_CONFIG();
	TRANS(dust_cal());
	HAL_Delay(2000);
	SSD1306_Clear();
	}
//	while(1){}
	
	
	else if(led_off_flag==1){
	SSD1306_GotoXY(20,25);
					SSD1306_Puts ("LED ON", &Font_11x18, 1);
					SSD1306_UpdateScreen();	
	
	led_off_flag=0;
	TIM16_CONFIG();
	TRANS(dust_cal());
	HAL_Delay(40);
	
	led_off_flag=0;
	led_off_flag=0;
	TIM16_CONFIG();
	TRANS(dust_cal());
	HAL_Delay(2000);
	SSD1306_Clear();
	}
	set_delay=0;
	halt_flag=0;
	dis_flag=1;
break;
}
}

//fan and uv led config
void uv_led_conf(void){
RCC->AHBENR |=(1<<17);
GPIOA->MODER |=(1<<14);
GPIOA->MODER &=~(1<<15);
GPIOA->PUPDR &=~(1<<14);
GPIOA->PUPDR &=~(1<<15);
}

//purifier mode fan and uv led
void fan_uv_mode1(void){
GPIOB->BSRR &=~(1<<17);
GPIOB->BSRR |=(1<<1);
TIM14->CR1 &=~(1<<0);
TIM14->CCR1 = 10000; //10000   4000
TIM14->EGR |=(1<<0);
TIM14->CR1 |=(1<<0);
GPIOA->ODR &=~(1<<7);
}

//silent mode fan and uv led
void fan_uv_mode3(void){
GPIOB->BSRR &=~(1<<17);
GPIOB->BSRR |=(1<<1);
TIM14->CR1 &=~(1<<0);
TIM14->CCR1 = 7000;//7000    10000
TIM14->EGR |=(1<<0);
TIM14->CR1 |=(1<<0);
unsigned long led_currentMillis = counter;
if (led_currentMillis - led_previousMillis >= 10000) {
led_previousMillis = led_currentMillis;
if (ledState == 0) {
GPIOA->ODR |=(1<<7);
ledState=1;
}else{
GPIOA->ODR &=~(1<<7);
ledState=0;
}
}
}

//auto mode fan and uv led
void fan_uv_mode2(void){
if(dust_cal()<=20){
GPIOA->ODR |=(1<<7);
GPIOB->BSRR &=~(1<<1);
GPIOB->BSRR |=(1<<17);
}	
if(dust_cal()>20&&dust_cal()<=250){
fan_uv_mode3();
}
else if(dust_cal()>250){
fan_uv_mode1();
}
}

//standby mode fan and uv led
void fan_uv_mode4(void){
//GPIOA->BSRR |=(1<<0);
//HAL_Delay(200);
//GPIOA->BSRR |=(1<<16);
TIM14->CR1 &=~(1<<0);
TIM14->CCR1 = 1000;
TIM14->EGR |=(1<<0);
TIM14->CR1 |=(1<<0);	
GPIOA->ODR |=(1<<7);
GPIOB->BSRR &=~(1<<1);
GPIOB->BSRR |=(1<<17);
}

/*

												while((set_delay<=50)||(halt_flag==0)){
													set_delay++;
											if(GPIOA->IDR &(1<<1)){
												set_delay=0;
											SET_INC++;
												HAL_Delay(100);
												if(SET_INC>2){
												SET_INC=1;
												}
												if(SET_INC!=0){halt_flag=1;}
												
											}	
									
if(SET_INC==1){
//cal
set_sel1=0;
set_sel2=1;
	sett_flag=1;

}


if(SET_INC==2){
//led
set_sel1=1;
set_sel2=0;
sett_flag=2;
}
											
													
					SSD1306_GotoXY(2,13);
					SSD1306_Puts ("CALIBRATION", &Font_11x18, set_sel1);
					SSD1306_UpdateScreen();	


					SSD1306_GotoXY(2,44);
					SSD1306_Puts ("LED", &Font_11x18, set_sel2);
					SSD1306_UpdateScreen();	

	
												//calibration_mode();
}
												

if(sett_flag==1){
	SSD1306_Clear();
	while(1){
calibration_mode();
	}
	
}
if(sett_flag==2){
SSD1306_Clear();
	
	
	
	SSD1306_GotoXY(20,25);
					SSD1306_Puts ("LED OFF", &Font_11x18, 1);
					SSD1306_UpdateScreen();	
	
	led_off_flag=1;
	TIM16_CONFIG();
	TRANS(dust_cal());
	HAL_Delay(40);
	
	led_off_flag=1;
	led_off_flag=1;
	TIM16_CONFIG();
	TRANS(dust_cal());
	HAL_Delay(2000);
	

//	while(1){}
}
*/
void set_fun(){
set_sel1=1;
set_sel2=1;
SET_INC=0;
	SSD1306_Clear();
	while((set_delay<=25)||(halt_flag==0)){
													set_delay++;
											if(GPIOA->IDR &(1<<1)){
												set_delay=0;
											SET_INC++;
												HAL_Delay(100);
												if(SET_INC>2){
												SET_INC=1;
												}
												if(SET_INC!=0){halt_flag=1;}
												
											}	
									
if(SET_INC==1){
//cal
set_sel1=0;
set_sel2=1;
	sett_flag=1;

}


if(SET_INC==2){
//led
set_sel1=1;
set_sel2=0;
sett_flag=2;
}
											
													
					SSD1306_GotoXY(2,13);
					SSD1306_Puts ("AQI STD", &Font_11x18, set_sel1);
					SSD1306_UpdateScreen();	


					SSD1306_GotoXY(2,44);
					SSD1306_Puts ("LED", &Font_11x18, set_sel2);
					SSD1306_UpdateScreen();	

	
												//calibration_mode();
}
												

if(sett_flag==1){
	        
	//

	
	sel_sel1=1;
sel_sel2=1;
SEl_INC=0;
	sel_delay=0;
	selection_no=0;
	SSD1306_Clear();
	std_spot1=read(21);
	HAL_Delay(100);                //dont channge
	std_spot2=read(22);
	HAL_Delay(100);
	 SSD1306_GotoXY(2,13);
					SSD1306_Puts ("INDIA", &Font_11x18, std_spot1);
					SSD1306_UpdateScreen();	
					SSD1306_GotoXY(2,44);
					SSD1306_Puts ("USA", &Font_11x18, std_spot2);
					SSD1306_UpdateScreen();
	
	while((sel_delay<=30)||(halt_flag_2==0)){
													sel_delay++;
											if(GPIOA->IDR &(1<<1)){
												sel_delay=0;
											SEl_INC++;
											selection_no++;
											HAL_Delay(100);
												if(SEl_INC>2){
												SEl_INC=1;
												}
												if(selection_no>2){
												selection_no=1;
													//SSD1306_Clear();
												}
												
												if(selection_no%2!=0){
												//SSD1306_Clear();
												}
												if(selection_no!=0){halt_flag_2=1;}
												
											}	
									
if(SEl_INC==1){
//cal
sel_sel1=0;
sel_sel2=1;
	sell_flag=1;
write(20,sell_flag);
	HAL_Delay(20);
	write(21,sel_sel1);
	HAL_Delay(20);
	write(22,sel_sel2);
}


if(SEl_INC==2){
//led
sel_sel1=1;
sel_sel2=0;
sell_flag=2;
write(20,sell_flag);
	HAL_Delay(20);
	write(21,sel_sel1);
	HAL_Delay(20);
	write(22,sel_sel2);
}
	
	
	
	
	
	       if((selection_no==1)||(selection_no==2)){
	        
	        SSD1306_GotoXY(2,13);
					SSD1306_Puts ("INDIA", &Font_11x18, sel_sel1);
					SSD1306_UpdateScreen();	
					SSD1306_GotoXY(2,44);
					SSD1306_Puts ("USA", &Font_11x18, sel_sel2);
					SSD1306_UpdateScreen();
				 }
				 
					
					
					
						
					
	
	//
	//HAL_Delay(5000);
//	SSD1306_Clear();
	
		set_delay=0;
	halt_flag=0;
				 	//sel_delay=0;
	
}
	halt_flag_2=0;
//**********************************8881
	//SSD1306_Clear();
}

if(sett_flag==2){
SSD1306_Clear();
	HAL_Delay(200);
	if(led_off_flag==0){
	SSD1306_GotoXY(20,25);
					SSD1306_Puts ("LED OFF", &Font_11x18, 1);
					SSD1306_UpdateScreen();	
	
	led_off_flag=1;
	TIM16_CONFIG();
	TRANS(dust_cal());
	HAL_Delay(40);
	
	led_off_flag=1;
	led_off_flag=1;
	TIM16_CONFIG();
	TRANS(dust_cal());
	HAL_Delay(2000);
	SSD1306_Clear();
	}
//	while(1){}
	
	
	else if(led_off_flag==1){
	SSD1306_GotoXY(20,25);
					SSD1306_Puts ("LED ON", &Font_11x18, 1);
					SSD1306_UpdateScreen();	
	
	led_off_flag=0;
	TIM16_CONFIG();
	TRANS(dust_cal());
	HAL_Delay(40);
	
	led_off_flag=0;
	led_off_flag=0;
	TIM16_CONFIG();
	TRANS(dust_cal());
	HAL_Delay(2000);
	SSD1306_Clear();
	}
	set_delay=0;
	halt_flag=0;
	}

}













//fan and uv led modes
void fan_uv(void){
switch(mode){
case 1:		fan_uv_mode1();
break;
case 2:		fan_uv_mode2();
break;
case 3:		fan_uv_mode3();
break;
case 4:		fan_uv_mode4();
break;
case 5:		mode=read(6);
break;	
}
}
int main(void)






{

  HAL_Init();
  SystemClock_Config();
  MX_GPIO_Init();
  MX_I2C1_Init();
	UART_CONFIG();
	buzzer_init();
	adc();	
	
	
	
	// Filter change eeprom clear
	write(100,0);
	HAL_Delay(100);
	write(105,0);
	HAL_Delay(100);
	write(110,0);
	HAL_Delay(100);
	write(115,0);
	HAL_Delay(100);
	

	
	
  min=read(100);
	HAL_Delay(100);
	hrs=read(105);
	HAL_Delay(100);
	day=read(110);
	HAL_Delay(100);
	month=read(115);
	HAL_Delay(100);
	mode=read(6);
	HAL_Delay(200);
offset_read=read(10);
HAL_Delay(200);
sign_offset=read(30);
HAL_Delay(200);
sell_flag=read(20);
HAL_Delay(200);
xoffset_read=read(60);
HAL_Delay(200);
xsign_offset=read(50);
HAL_Delay(200);




	counter_timer_config();
	butt_config();
	//PWM();
	uv_led_conf();
 // UART_CONFIG();
	HAL_Delay(10);
	SSD1306_Init();	
  SSD1306_Fill(0x00);
  SSD1306_UpdateScreen();
  HAL_Delay(300);
  SSD1306_Clear();
	
	//test11=a[1];
	
	
	if((!((a[0]==66)&&(a[1]==77)))&&(!((a[0]==0)&&(a[1]==0)))){
	
	HAL_NVIC_SystemReset();
	
	}
	
	PWM();
	//
	if(GPIOA->IDR &(1<<1)){
calib_mode=1;
HAL_Delay(2000);
	
calib_color_flag=1;	
TIM16_CONFIG();
TRANS(dust_cal());
HAL_Delay(40);	
		//BUZZER
					GPIOA->ODR |=(1<<7);
					GPIOB->BSRR &=~(1<<1);
					GPIOB->BSRR |=(1<<17);
		//BUZZER END
		
				  SSD1306_GotoXY(2,13);
					SSD1306_Puts ("CALIBRATION", &Font_11x18, set_sel1);
					SSD1306_UpdateScreen();	
	  HAL_Delay(2000);
	SSD1306_Clear();





while((calset_delay<=50)||(calhalt_flag==0)){
													calset_delay++;
											if(GPIOA->IDR &(1<<1)){
												calset_delay=0;
											calSET_INC++;
												HAL_Delay(100);
												if(calSET_INC>2){
												calSET_INC=1;
												}
												if(calSET_INC!=0){calhalt_flag=1;}
												
											}	
									
if(calSET_INC==1){
//cal
calset_sel1=0;
calset_sel2=1;
	calsett_flag=1;

}


if(calSET_INC==2){
//led
calset_sel1=1;
calset_sel2=0;
calsett_flag=2;
}
											
													
					SSD1306_GotoXY(2,13);
					SSD1306_Puts ("TEMP", &Font_11x18, calset_sel1);
					SSD1306_UpdateScreen();	


					SSD1306_GotoXY(2,44);
					SSD1306_Puts ("PPM", &Font_11x18, calset_sel2);
					SSD1306_UpdateScreen();	

	
												//calibration_mode();
}

}
if(calsett_flag==1){
	SSD1306_Clear();
	while(1){
calibration_mode();
	}
	
}
if(calsett_flag==2){
SSD1306_Clear();
	
	
	while((incdecset_delay<=50)||(incdechalt_flag==0)){
													incdecset_delay++;
											if(GPIOA->IDR &(1<<1)){
												incdecset_delay=0;
												
											incdecSET_INC++;
												HAL_Delay(100);
												if(incdecSET_INC>2){
												incdecSET_INC=1;
												}
												if(incdecSET_INC!=0){incdechalt_flag=1;}
												
											}	
									
if(incdecSET_INC==1){
//cal
incdecset_sel1=0;
incdecset_sel2=1;
	incdecsett_flag=1;

}


if(incdecSET_INC==2){
//led
incdecset_sel1=1;
incdecset_sel2=0;
incdecsett_flag=2;
}
		
		SSD1306_GotoXY(10,44);
					SSD1306_Puts ("DEC", &Font_11x18, incdecset_sel1);
					SSD1306_UpdateScreen();	
		SSD1306_GotoXY(85,44);
					SSD1306_Puts ("INC", &Font_11x18, incdecset_sel2);
					SSD1306_UpdateScreen();	
		
		
		
		//PPM DISPLAY START********************************************
			if((a[0]==66)&&(a[1]==77)){
ppm=a[12]<<8|a[13];
	
	}
	if((a[1]==66)&&(a[2]==77)){
ppm=a[13]<<8|a[14];
		
	}
	
	
	sprintf(print_ppm,"%d",ppm); 
	
	SSD1306_GotoXY(30,10);
SSD1306_Puts ("PPM", &Font_11x18, 1); 
	SSD1306_GotoXY(92,10);
SSD1306_Puts ("  ", &Font_11x18, 1);
SSD1306_GotoXY(77,10);
SSD1306_Puts (print_ppm, &Font_11x18, 1);
	
	//
	if(ppm<1000)
	{
	SSD1306_GotoXY(108,10);	
SSD1306_Puts ("          ", &Font_16x26, 1);	
	
	}
	if(ppm<10)
	{
	SSD1306_GotoXY(86,10);	
SSD1306_Puts ("          ", &Font_16x26, 1);	
	
	}
	
	//
	
	
	
					SSD1306_UpdateScreen();	
	
	//PPM DISPLAY STOP***********************************************************
	
	
	storedppm=ppm;
	}

	
	if(incdecsett_flag==1){
		
					SSD1306_Clear();
	while(1){
			calibration_dec();
	}
		
	
	}
	
	
	
		if(incdecsett_flag==2){
			SSD1306_Clear();
	while(1){
			calibration_inc();
	}
	}
	
}


SSD1306_Clear();





	SSD1306_GotoXY(15,25);
SSD1306_Puts ("C O R S A", &Font_11x18, 1);              
SSD1306_UpdateScreen();

startup_color_flag=1;	
									TIM16_CONFIG();
									TRANS(dust_cal());
									HAL_Delay(40);


if(mode!=3){
//buzzer 
GPIOA->BSRR |=(1<<0);
HAL_Delay(50);
GPIOA->BSRR |=(1<<16);
HAL_Delay(100);
GPIOA->BSRR |=(1<<0);
HAL_Delay(50);
GPIOA->BSRR |=(1<<16);
HAL_Delay(100);
GPIOA->BSRR |=(1<<0);
HAL_Delay(50);
GPIOA->BSRR |=(1<<16);
HAL_Delay(1000);
}
else if(mode==3){
HAL_Delay(1000);
}
HAL_Delay(300);
SSD1306_Clear();
HAL_Delay(200);
	
	
	
	//
	
	
	
	
	
	
//


SSD1306_Clear();
















//change filter(edit line 221 also) 
if(month>=6)
{
SSD1306_Clear();
SSD1306_GotoXY(35,13);
SSD1306_Puts ("CHANGE", &Font_11x18, 1);
SSD1306_UpdateScreen();		
SSD1306_GotoXY(35,44);
SSD1306_Puts ("FILTER", &Font_11x18, 1);
SSD1306_UpdateScreen();
	fan_uv_mode3();
	
	
//GPIOA->ODR |=(1<<7);
//GPIOB->BSRR &=~(1<<1);
//GPIOB->BSRR |=(1<<17);
	filter_change_color_flag2=1;	
									TIM16_CONFIG();
									TRANS(dust_cal());
									HAL_Delay(40);

	

while(month>=6){
    HAL_Delay(40);
	
unsigned long currentMillis_buzzer_changefilter = counter;
if (currentMillis_buzzer_changefilter - previousMillis_buzzer >= interval_buzzer_changefilter) {
previousMillis_buzzer = currentMillis_buzzer_changefilter;
if (buzzerState == 0){
      buzzerState = 1;
			GPIOA->BSRR |=(1<<0);
													filter_change_color_flag=1;	
													TIM16_CONFIG();
													TRANS(dust_cal());
													HAL_Delay(40);	
			HAL_Delay(100);
	    GPIOA->BSRR |=(1<<16);
													filter_change_color_flag2=1;	
													TIM16_CONFIG();
													TRANS(dust_cal());
													HAL_Delay(40);	
			HAL_Delay(300);
			GPIOA->BSRR |=(1<<0);
	
													filter_change_color_flag=1;	
													TIM16_CONFIG();
													TRANS(dust_cal());
													HAL_Delay(40);	
			HAL_Delay(100);
	    GPIOA->BSRR |=(1<<16);
			
													filter_change_color_flag2=1;	
													TIM16_CONFIG();
													TRANS(dust_cal());
													HAL_Delay(40);	
} else {
      buzzerState = 0;
			GPIOA->BSRR |=(1<<16);
													filter_change_color_flag2=1;	
													TIM16_CONFIG();
													TRANS(dust_cal());
													HAL_Delay(40);	
} 
}
if(GPIOA->IDR &(1<<1)){
filter_while_delay++;
HAL_Delay(1000);
}
if(filter_while_delay > 10){
min=0;
write(100,min);
HAL_Delay(100);
hrs=0;
write(105,hrs);
HAL_Delay(100);
day=0;
write(110,day);
HAL_Delay(100);
month=0;
write(115,month);
HAL_Delay(100);
filter_while_delay=0;
filter_change_color_flag=0;
SSD1306_Clear();
}			
}
}		


present_menu();
HAL_Delay(2000);
//SSD1306_Clear();
//temp();
//HAL_Delay(10000);
SSD1306_Clear();

	//HAL_Delay(10);
adc_to_mv();

while (1)
{


seconds();
corsa();
	}
}

void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_I2C1;
  PeriphClkInit.I2c1ClockSelection = RCC_I2C1CLKSOURCE_HSI;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}
static void MX_I2C1_Init(void)
{
  hi2c1.Instance = I2C1;
  hi2c1.Init.Timing = 0x0000020B;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_I2CEx_ConfigAnalogFilter(&hi2c1, I2C_ANALOGFILTER_ENABLE) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_I2CEx_ConfigDigitalFilter(&hi2c1, 0) != HAL_OK)
  {
    Error_Handler();
  }
}
static void MX_GPIO_Init(void)
{
  __HAL_RCC_GPIOA_CLK_ENABLE();

}
void Error_Handler(void)
{
  __disable_irq();
  while (1)
  {
  }
}

#ifdef  USE_FULL_ASSERT
void assert_failed(uint8_t *file, uint32_t line)
{
}
#endif 

