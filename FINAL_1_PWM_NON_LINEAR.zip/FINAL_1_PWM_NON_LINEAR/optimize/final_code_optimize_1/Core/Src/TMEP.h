#include <stm32f042x6.h>
#include "main.h"

volatile int val=0;
volatile int val_arr[2];
short degrees=0;
int adc_to_mv();

int avgi=0;

void Dma_adc(void){


	//DMA CLK ENABLE
  RCC->AHBENR |=(1<<0);

//ADDRESS OF USART2 RDR
	DMA1_Channel1->CPAR=(uint32_t)&ADC1->DR;

//ADDRESS OF ARRAY 
	DMA1_Channel1->CMAR=(uint32_t)val_arr;


//NUMBER OF DATA TO BE TRANSFERED
	DMA1_Channel1->CNDTR=2;

//MEMORY SIZE 32 BIT
DMA1_Channel1->CCR &=~(1U<<10);
DMA1_Channel1->CCR |=(1U<<11);
	
	//PHERIPERAL SIZE 32BIT
DMA1_Channel1->CCR &=~(1U<<8);
DMA1_Channel1->CCR |=(1U<<9);

//MEMORY INCREMENT MODE
	DMA1_Channel1->CCR |=(1U<<7);
	
	//READ FROM pheripheral
	DMA1_Channel1->CCR &=~(1U<<4);
	
	//TRANSFER COMPLETE INTURRPT ENABLE
	DMA1_Channel1->CCR |=(1U<<1);
	
	//CIRCULAR MODE ENABLE
	DMA1_Channel1->CCR |=(1U<<5);
	//enabble dma
	DMA1_Channel1->CCR |=(1U<<0);
	
	//NVIC_EnableIRQ(DMA1_Channel1_IRQn); /* (1) */
//NVIC_SetPriority(DMA1_Channel1_IRQn,0); /* (2) */
	
}



void DMA1_Channel1_IRQHandler(void){

	 DMA1->IFCR |=(1<<13);
	DMA1_Channel1->CCR &=~(1U<<1);
}


void adc(void){


	//GPIOA ENABLE
	RCC->AHBENR |=(1<<17);
	
	//ENABLE ADC
	RCC->APB2ENR |=(1<<9);
	
	//PA6 AS ANALOG MODE
	GPIOA->MODER |=(1<<12);
	GPIOA->MODER |=(1<<13);
	
	//ENABLE CONVERTION INTURRPT
	//ADC1->IER |=(1<<2);
	//NVIC_EnableIRQ(ADC1_IRQn);
	//NVIC_SetPriority(ADC1_IRQn,2);
	
	
	
	//SAMPLE TIME
//	ADC1->SMPR |=(1<<0);
//	ADC1->SMPR |=(1<<1);
//	ADC1->SMPR |=(1<<2);
	
	//CHANNEL SELECTION
	ADC1->CHSELR |=(1<<6);

	
	
	//ENABLE EOC 
	ADC1->IER|=(1<<2);
	
	
	//SET TO CONTIOUES MODE
	ADC1->CFGR1 |=(1<<13);
	
	//CIRCULAR ENABLE 
	ADC1->CFGR1|=(1<<1);
	
	
	//DMA ENABLE
	ADC1->CFGR1|=(1<<0);
	
	//ENABLE CALIBRATION
	
	ADC1->CR &=~(1<<0);
		ADC1->CR |=(1<<31);
		
		
		HAL_Delay(2);
		
		
		
	//ENABLE ADC
	ADC1->CR |=(1<<0);
	while(!(ADC1->ISR & (1<<0)));
	
			


	

	

		ADC1->CR |=(1<<2);
//	Dma_adc();
	


}









int adc_to_mv(){
	
	
	
	while ((ADC1->ISR & ADC_ISR_EOC) == 0);

	val =0; 
	for(avgi=0;avgi<=20;avgi++){
		
	
	val=(ADC1->DR)+val;
		
	}
	val=val/21;
	
	degrees = (( 3.3 / 4096) * val)*100;



return degrees;
}