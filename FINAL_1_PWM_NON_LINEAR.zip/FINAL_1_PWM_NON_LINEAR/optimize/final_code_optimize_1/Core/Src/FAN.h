#include <stm32f042x6.h>







void PWM(void){

	//fan on configuration
	//enable port bB clk
	RCC->AHBENR |=(1<<18);
	
	//General purpose output mode for PB1
	GPIOB->MODER |=(1<<2);
	GPIOB->MODER &=~(1<<3);
	
	//PULL UP PB1
	GPIOB->PUPDR |=(1<<2);
	GPIOB->PUPDR &=~(1<<3);
	
	//Sets the corresponding ODRx bit
	GPIOB->BSRR |=(1<<1);
	
	
	
	
	RCC->AHBENR |=(1<<17);
	RCC->APB1ENR |=(1<<8);
	
	GPIOA->MODER |=(1<<9);
	GPIOA->MODER &=~(1<<8);
	
	
	GPIOA->OTYPER &=~(1<<4);
	GPIOA->OSPEEDR |=(1<<8);
	GPIOA->OSPEEDR |=(1<<9);
	
	GPIOA->AFR[0] |=(1<<18);
	GPIOA->AFR[0] &=~(1<<19);
	GPIOA->AFR[0] &=~(1<<17);
	GPIOA->AFR[0] &=~(1<<16);
	
	//ENABLE THE COMPARE REGISTER
	TIM14->CCER |=(1<<0);
	
		
	//ENABLE THE PRELOAD REGISTER(ARPE)
	TIM14->CR1 |=(1<<7);
	
	//PWM MODE 1
	TIM14->CCMR1 |=(1<<6);
	TIM14->CCMR1 |=(1<<5);
	TIM14->CCMR1 &=~(1U<<4);
	
	//ENABLE THE PRELOAD BUFFER
	TIM14->CCMR1 |=(1<<3);
	

	
	
	
	
	
	
	
	
	TIM14->PSC =8;
	TIM14->ARR =10000;
	TIM14->CCR1 = 10000;//39321
	
//UG BIT HIGH
	TIM14->EGR |=(1<<0);
	//ENABLE THE COUNTER
	TIM14->CR1 |=(1<<0);
	
	
	
	

}




